function t(t){const e=t;return"AbortError"===(e?.name||"")||/timeout/i.test(e?.message||"")}export{t as i};
